<?php

class UsersModel extends BaseModel
{
    // TODO: your database access functions for the user register / login will come here ...
}
