<?php

class HomeModel extends BaseModel
{
    // TODO: your database access functions for the home page will come here ...
}
