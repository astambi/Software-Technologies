<?php

class UsersController extends BaseController
{
    public function register()
    {
		// TODO: your user registration functionality will come here ...
    }

    public function login()
    {
		// TODO: your user login functionality will come here ...
    }

    public function logout()
    {
		// TODO: your user logout functionality will come here ...
    }
}
