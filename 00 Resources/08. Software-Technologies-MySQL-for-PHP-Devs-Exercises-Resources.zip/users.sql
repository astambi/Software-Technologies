INSERT INTO `users` (`id`, `username`, `password`, `fullname`) VALUES
(1, 'Pesho', '202cb962ac59075b964b07152d234b70', 'Petar Petrov'),
(2, 'Gosho', 'caf1a3dfb505ffed0d024130f58c5cfa', 'Georgi Georgiev'),
(3, 'Tosho', 'c4ca4238a0b923820dcc509a6f75849b', 'Todor Todorov'),
(4, 'Mariika', 'c81e728d9d4c2f636f067f89cc14862c', 'Mariya Mariyova'),
(5, 'Stamat', 'eccbc87e4b5ce2fe28308fd9f2a7baf3', 'Stamat Stamatov');